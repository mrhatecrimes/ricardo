document.getElementById("mainTitle").innerText = "Point and click adventure";

const offsetCharacter = 16;

const sec = 1000;

const mainCharacter = document.getElementById("mainCharacter");
const gameWindow = document.getElementById("gameWindow");
const characterAudio = document.getElementById("characterAudio");
const mainCharacterSpeech = document.getElementById("mainCharacterSpeech");

const counterSpeech = document.getElementById("counterSpeech");


gameWindow.onclick = function (e) {

    var rect = gameWindow.getBoundingClientRect();
    var x = e.clientX - rect.left;
    var y = e.clientY - rect.top;  
    mainCharacter.style.left = x - offsetCharacter + "px";
    mainCharacter.style.top = y - offsetCharacter + "px";

    console.log(e.target.id);

    switch (e.target.id) {
        case "door1":            showSpeech(mainCharacterSpeech, characterAudio, "this is door one.<br> And it's locked dummy...");
            break;
        case "door2":
            showSpeech(mainCharacterSpeech, characterAudio, "noboby is home...<br> Come back later..");
            break;
        case "tree":
            showSpeech(mainCharacterSpeech, characterAudio, "Nice tree... looking good.. You come here often? nudge nudge...");
            break;
        default:
            hideSpeech();
            break;
    }}

function showSpeech(targetBubble, targetAudio, dialogue) {    targetBubble.style.opacity = 1;
    targetBubble.innerHTML = dialogue;
    targetAudio.currentTime = 0;
    targetAudio.play();
    setTimeout(hideSpeech, 4 * sec);
}

function hideSpeech() {
    mainCharacterSpeech.style.opacity = 0;
    mainCharacterSpeech.innerHTML = "...";
    characterAudio.pause();
}
